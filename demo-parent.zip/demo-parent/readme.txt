demo-parent

The common parent pom for all demo projects does the folowing:  

1.  Establish property file conventions.

2.  Provides profiles for different target platforms: 
    spring, tomcat, jetty, karaf

3.  Relates property conventions to the platforms.

4.  Provides profiles for different sets of utilities: 
    logging

Usage

Properties Conventions 
 The goal is to be able to use only relative pathnames for all resources at
 runtime in a manner that is property driven and invariant across different
 platforms.

 Each platform profile uses the properties-maven-plugin to read three properties 
 files for project, app, and container.

 Project properties are used only at build time.  It is located in the project
 root:
   ${project.artifactId}.build.properties

 Application specific properties are located in the resources directory.  It is
 available at both build and runtime.
   /src/main/resources/${project.artifactId}.properties

 Container specific properties are located in the resources directory.  It is
 available at both build and runtime.  The container property file name follows
 the convention of springContainer, tomcatContainer, etc.
   src/main/resources/${container}.properties

 The path to the container properties file will vary based on whether it is
 being referenced from maven at build time or from the application itself at
 runtime.  When  accessed at runtime the path will vary based on the platform.
 For example, Spring apps will deploy the property to the root of the jar and
 hence the root of classpath.  On the other hand a tomcat webapp will deploy to
 the WEB-INF directory.

 To avoid duplicate and possibly inconsistent Spring and Maven properties,
 a System Property is used to look up the property files described above.  

 Spring will include system properties in its search to match placeholders in 
 the spring xml, but it does not check system properties when interpreting the 
 spring properties files themselves. (Verify)  

 As a result, the only System Properties that need to be set are the following:
    app-properties.runtime.url (required)
    container-properties.runtime.url (required)
    container (optional) - name of the container
    propertiesPath  (optional) root of runtime resource directory
 At _runtime_ they will be used by the Spring property placeholder to load 
 container specific property files.  Both the container file name and the path to
 it will vary based on the target platform.  
 At _buildtime_ the path to the container specific properties is:
   src/main/resources/${propertiesPath}${container}Container.properties 
 The _runtime_ path to the same container specific properties is:
   ${propertiesPath}${container}Container.properties
 
 At _runtime_ this path could be relative to the classpath or to the target
 platform.  For example, for a spring jar it would be in the classpath root, so
 the propertiesPath would be the empty string.  For a tomcat or jetty project it
 would be in the WEB-INF/ directory.  Note that there is no separator between
 the properties.  That is because some of the time a relative root is based on
 the classpath and it should be blank.

 Both Spring and Maven allow cross-referencing of properties within a property
 file:
   host=localhost
   port=8080
   url=${host}:${port}  

Platform Profiles 
 The Spring profile results in simple jars which can be run from OS
 command line.  Additional steps are required to deploy the jetty, karaf, and
 tomcat artifacts to the target server.
 
Build Configurations
 Profiles are controlled via flag files names myProfile.profile.  For example, 
 spring.profile.  Profiles which are not active typically have a file named  
 myProfile.profile.disabled to explicitly indicate the status, but are not
 required per se.  

 Multiple profile flag files are grouped into different build configurations in
 subdirectories located under the profiles directory, e.g. profiles/myConfig.
 Which build configuration is used is controlled by the environment variable 
 buildConfiguration system variable.  

 When launching Maven from the command line the entire configuration is enabled
 with a single parameter
 
 mvn -DbuildConfiguration=mySpringServer install
 
 Note that these build configurations should only apply to the "leaf" nodes of
 the dependency tree.  Common dependencies should only have a single build 
 target.  If multiple build configurations are desired for the same module,
 they should be distinguished with different classifiers.

 In general, different types of modules will have different sets of profiles
 included in the profiles directory.  POJO modules should not need to specify
 any profiles although logging is a common utility profile.  Application 
 modules will need platform profile, e.g. spring, karaf, tomcat, jetty.

 NOTE: Remember that if explicit profiles are specified in the maven commandline 
 using the -P option, then _only_ those profiles are activated.  So it is much 
 better to use files and environment variables. In general, builds should be 
 able to function without any commandline profiles, instead using the profile 
 indicator files.  

Test Containers
 Builds should always use mvn install without explicit profile flags.
 Profiles for running test containers need to explicitly include all profiles.

 For Eclipse it is important to use the M2 run configuration
(not the external application commands).  

 The Jetty and Tomcat builds require changing the packaging in the POM to war.

 Spring (Camel):
  From the service project
    mvn camel:run

 Tomcat:
  Note that the target packaging will need to be war.
  To run a tomcat instance from maven go to the Service project.

    mvn tomcat7:run-war
    mvn tomcat7:deploy

 Jetty Build:
  Note that the target packaging will need to be war.
  To run a jetty instance from maven go to the Service project.

    mvn jetty:run-war
    mvn jetty:deploy  


Types of Projects

  There are four types of child subprojects.
    Utility projects such as utilities, spring-util, camel-util.  
    Infrastructure poms include the parent, runner, and util projects.
    Component projects that implement individual components designed to be
      realize a service within an Application.  These typically have
      two subtypes, pure business logic and service layers.  The business
      logic and service layers may or may not be delivered via separate
      jars/bundles/projects, but they should be in separate packages.
    Application projects group Services into deployable units.
